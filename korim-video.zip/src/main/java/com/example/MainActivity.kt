package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.BottomNavBar
import com.example.ui.screens.CommentsBottomSheet
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InboxScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.UploadScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KorimVideoApp(viewModel)
            }
        }
    }
}

@Composable
fun KorimVideoApp(viewModel: MainViewModel) {
    val videos by viewModel.videos.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val homeSubTab by viewModel.homeSubTab.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedVideoId by viewModel.selectedVideoId.collectAsStateWithLifecycle()
    val comments by viewModel.comments.collectAsStateWithLifecycle()

    var showSettings by remember { mutableStateOf(false) }

    val unreadNotificationsCount = remember(notifications) {
        notifications.count { !it.isRead }
    }

    if (showSettings) {
        BackHandler { showSettings = false }
        SettingsScreen(onBack = { showSettings = false })
        return
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            BottomNavBar(
                selectedTab = selectedTab,
                onTabSelected = { tab ->
                    viewModel.setTab(tab)
                    showSettings = false
                },
                unreadNotificationsCount = unreadNotificationsCount
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> HomeScreen(
                    videos = videos,
                    homeSubTab = homeSubTab,
                    onSubTabChanged = { viewModel.setHomeSubTab(it) },
                    onLikeClicked = { viewModel.toggleLike(it) },
                    onFollowClicked = { username, status -> viewModel.toggleFollow(username, status) },
                    onCommentClicked = { videoId -> viewModel.selectVideoForComments(videoId) }
                )
                1 -> DiscoverScreen(
                    videos = videos,
                    searchQuery = searchQuery,
                    onSearchQueryChanged = { viewModel.setSearchQuery(it) },
                    onVideoClicked = { videoId -> viewModel.selectVideoForComments(videoId) }
                )
                2 -> UploadScreen(
                    onUploadSubmitted = { title, uri, caption, sound ->
                        viewModel.uploadVideo(title, uri, caption, sound)
                    }
                )
                3 -> InboxScreen(
                    notifications = notifications,
                    onMarkAllRead = { viewModel.markNotificationsRead() }
                )
                4 -> ProfileScreen(
                    videos = videos,
                    onVideoClicked = { videoId -> viewModel.selectVideoForComments(videoId) },
                    onOpenSettings = { showSettings = true }
                )
            }

            // Comments Bottom Sheet
            if (selectedVideoId != null) {
                CommentsBottomSheet(
                    videoId = selectedVideoId!!,
                    comments = comments,
                    onDismiss = { viewModel.selectVideoForComments(null) },
                    onAddComment = { text -> viewModel.addComment(selectedVideoId!!, text) }
                )
            }
        }
    }
}
