package com.example.ui.screens

import android.content.Intent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.VideoEntity
import com.example.ui.components.VideoPlayerView
import com.example.ui.theme.KorimRed
import com.example.ui.theme.KorimWhite

@Composable
fun HomeScreen(
    videos: List<VideoEntity>,
    homeSubTab: Int,
    onSubTabChanged: (Int) -> Unit,
    onLikeClicked: (VideoEntity) -> Unit,
    onFollowClicked: (String, Boolean) -> Unit,
    onCommentClicked: (Long) -> Unit
) {
    val filteredVideos = remember(videos, homeSubTab) {
        if (homeSubTab == 1) videos.filter { it.isFollowing } else videos
    }

    val pagerState = rememberPagerState(pageCount = { maxOf(1, filteredVideos.size) })

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (filteredVideos.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (homeSubTab == 1) "No following accounts yet.\nFollow creators to see their videos!" else "No videos available.",
                    color = Color.Gray,
                    fontSize = 14.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }
        } else {
            VerticalPager(
                state = pagerState,
                modifier = Modifier.fillMaxSize()
            ) { page ->
                val video = filteredVideos[page]
                val isCurrentPage by remember { derivedStateOf { pagerState.currentPage == page } }

                Box(modifier = Modifier.fillMaxSize()) {
                    VideoPlayerView(
                        videoUrl = video.videoUrl,
                        thumbnailUrl = video.thumbnailUrl,
                        isPlaying = isCurrentPage,
                        modifier = Modifier.fillMaxSize()
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.7f)
                                    ),
                                    startY = 800f
                                )
                            )
                    )

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 16.dp, bottom = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(52.dp),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            AsyncImage(
                                model = video.userAvatar,
                                contentDescription = video.username,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color.DarkGray)
                            )
                            if (!video.isFollowing) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(KorimRed)
                                        .clickable { onFollowClicked(video.username, video.isFollowing) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Follow",
                                        tint = KorimWhite,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = { onLikeClicked(video) },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "Like",
                                    tint = if (video.isLiked) KorimRed else KorimWhite,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            Text(
                                text = "${video.likesCount}",
                                color = KorimWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(
                                onClick = { onCommentClicked(video.id) },
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ModeComment,
                                    contentDescription = "Comment",
                                    tint = KorimWhite,
                                    modifier = Modifier.size(30.dp)
                                )
                            }
                            Text(
                                text = "${video.commentsCount}",
                                color = KorimWhite,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        val context = LocalContext.current
                        IconButton(
                            onClick = {
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, "Check out this awesome video on Korim Video: ${video.videoUrl}")
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, null)
                                context.startActivity(shareIntent)
                            },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share",
                                tint = KorimWhite,
                                modifier = Modifier.size(30.dp)
                            )
                        }

                        val infiniteTransition = rememberInfiniteTransition(label = "music")
                        val angle by infiniteTransition.animateFloat(
                            initialValue = 0f,
                            targetValue = 360f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(4000, easing = LinearEasing),
                                repeatMode = RepeatMode.Restart
                            ),
                            label = "angle"
                        )
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.DarkGray)
                                .rotate(angle),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = "Sound",
                                tint = KorimWhite,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(start = 16.dp, end = 88.dp, bottom = 24.dp)
                    ) {
                        Text(
                            text = "@${video.username}",
                            color = KorimWhite,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = video.caption,
                            color = KorimWhite.copy(alpha = 0.9f),
                            fontSize = 14.sp,
                            maxLines = 3
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.MusicNote,
                                contentDescription = null,
                                tint = KorimWhite,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = video.soundName,
                                color = KorimWhite.copy(alpha = 0.8f),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Following",
                color = if (homeSubTab == 1) KorimWhite else Color.Gray,
                fontWeight = if (homeSubTab == 1) FontWeight.Bold else FontWeight.Normal,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onSubTabChanged(1) }
            )
            Text(
                text = "|",
                color = Color.Gray,
                fontSize = 14.sp
            )
            Text(
                text = "For You",
                color = if (homeSubTab == 0) KorimWhite else Color.Gray,
                fontWeight = if (homeSubTab == 0) FontWeight.Bold else FontWeight.Normal,
                fontSize = 16.sp,
                modifier = Modifier.clickable { onSubTabChanged(0) }
            )
        }
    }
}
