package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.VideoEntity
import com.example.ui.theme.KorimBlack
import com.example.ui.theme.KorimDarkGray
import com.example.ui.theme.KorimRed
import com.example.ui.theme.KorimSurface
import com.example.ui.theme.KorimWhite

@Composable
fun ProfileScreen(
    videos: List<VideoEntity>,
    onVideoClicked: (Long) -> Unit,
    onOpenSettings: () -> Unit
) {
    var profileTab by remember { mutableStateOf(0) } // 0: Posted, 1: Liked

    val myVideos = remember(videos) {
        videos.filter { it.username == "my_korim_user" || it.username == "elena_vibe" }
    }
    val likedVideos = remember(videos) {
        videos.filter { it.isLiked }
    }

    val displayVideos = if (profileTab == 0) myVideos else likedVideos

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KorimBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "@my_korim_user",
                color = KorimWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            IconButton(onClick = onOpenSettings) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = KorimWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        AsyncImage(
            model = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200",
            contentDescription = "Profile Avatar",
            modifier = Modifier
                .size(88.dp)
                .clip(CircleShape)
                .background(KorimDarkGray)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Korim Creator",
            color = KorimWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Digital creator & short video enthusiast. Sharing moments that matter! 🎬✨",
            color = Color.Gray,
            fontSize = 13.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "142", color = KorimWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = "Following", color = Color.Gray, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "3.8K", color = KorimWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = "Followers", color = Color.Gray, fontSize = 12.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = "24.5K", color = KorimWhite, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(text = "Likes", color = Color.Gray, fontSize = 12.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = { /* Edit profile action */ },
            modifier = Modifier
                .width(160.dp)
                .height(36.dp),
            shape = RoundedCornerShape(18.dp)
        ) {
            Text(text = "Edit Profile", color = KorimWhite, fontSize = 13.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        TabRow(
            selectedTabIndex = profileTab,
            containerColor = KorimBlack,
            contentColor = KorimWhite,
            indicator = { tabPositions ->
                Box(
                    modifier = Modifier
                        .tabIndicatorOffset(tabPositions[profileTab])
                        .height(2.dp)
                        .background(KorimRed)
                )
            },
            divider = {}
        ) {
            Tab(
                selected = profileTab == 0,
                onClick = { profileTab = 0 },
                icon = {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = "Posted",
                        tint = if (profileTab == 0) KorimRed else Color.Gray
                    )
                }
            )
            Tab(
                selected = profileTab == 1,
                onClick = { profileTab = 1 },
                icon = {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Liked",
                        tint = if (profileTab == 1) KorimRed else Color.Gray
                    )
                }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            contentPadding = PaddingValues(bottom = 80.dp)
        ) {
            items(displayVideos) { video ->
                Box(
                    modifier = Modifier
                        .height(160.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(KorimSurface)
                        .clickable { onVideoClicked(video.id) }
                ) {
                    AsyncImage(
                        model = video.thumbnailUrl,
                        contentDescription = video.title,
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
