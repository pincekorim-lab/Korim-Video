package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Report
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.KorimBlack
import com.example.ui.theme.KorimDarkGray
import com.example.ui.theme.KorimRed
import com.example.ui.theme.KorimWhite

@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {
    var isPrivateAccount by remember { mutableStateOf(false) }
    var pushNotifications by remember { mutableStateOf(true) }
    var darkMode by remember { mutableStateOf(true) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(KorimBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Spacer(modifier = Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = KorimWhite)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Settings & Safety",
                color = KorimWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(text = "ACCOUNT & PRIVACY", color = KorimRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        SettingToggleItem(
            icon = Icons.Default.Lock,
            title = "Private Account",
            subtitle = "Only approved followers can view your videos",
            checked = isPrivateAccount,
            onCheckedChange = { isPrivateAccount = it }
        )

        SettingToggleItem(
            icon = Icons.Default.Security,
            title = "Push Notifications",
            subtitle = "Receive alerts for likes, comments, and followers",
            checked = pushNotifications,
            onCheckedChange = { pushNotifications = it }
        )

        SettingToggleItem(
            icon = Icons.Default.Palette,
            title = "Dark Theme",
            subtitle = "Always use immersive dark mode",
            checked = darkMode,
            onCheckedChange = { darkMode = it }
        )

        Spacer(modifier = Modifier.height(24.dp))
        Divider(color = KorimDarkGray)
        Spacer(modifier = Modifier.height(24.dp))

        Text(text = "SAFETY & MODERATION", color = KorimRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        SettingActionItem(
            icon = Icons.Default.Report,
            title = "Report Content or Bug",
            subtitle = "Help us keep Korim Video safe and clean"
        ) {}

        SettingActionItem(
            icon = Icons.Default.Block,
            title = "Blocked Accounts",
            subtitle = "Manage blocked users and interactions"
        ) {}

        Spacer(modifier = Modifier.height(24.dp))
        Divider(color = KorimDarkGray)
        Spacer(modifier = Modifier.height(24.dp))

        SettingActionItem(
            icon = Icons.Default.ExitToApp,
            title = "Log Out",
            subtitle = "Sign out of your Korim account",
            textColor = KorimRed
        ) {}
    }
}

@Composable
fun SettingToggleItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = KorimWhite, modifier = Modifier.size(24.dp))
            Column {
                Text(text = title, color = KorimWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = subtitle, color = Color.Gray, fontSize = 12.sp)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = KorimWhite,
                checkedTrackColor = KorimRed,
                uncheckedThumbColor = Color.Gray,
                uncheckedTrackColor = KorimDarkGray
            )
        )
    }
}

@Composable
fun SettingActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    textColor: Color = KorimWhite,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(24.dp))
        Column {
            Text(text = title, color = textColor, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, color = Color.Gray, fontSize = 12.sp)
        }
    }
}
