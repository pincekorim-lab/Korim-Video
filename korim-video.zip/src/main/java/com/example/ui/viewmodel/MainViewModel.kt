package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.CommentEntity
import com.example.data.NotificationEntity
import com.example.data.VideoEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application, viewModelScope)
    private val videoDao = database.videoDao()
    private val commentDao = database.commentDao()
    private val notificationDao = database.notificationDao()

    val videos: StateFlow<List<VideoEntity>> = videoDao.getAllVideos()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<NotificationEntity>> = notificationDao.getAllNotifications()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedVideoId = MutableStateFlow<Long?>(null)
    val selectedVideoId = _selectedVideoId.asStateFlow()

    private val _comments = MutableStateFlow<List<CommentEntity>>(emptyList())
    val comments = _comments.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(0) // 0: Home, 1: Discover, 2: Upload, 3: Inbox, 4: Profile
    val selectedTab = _selectedTab.asStateFlow()

    private val _homeSubTab = MutableStateFlow(0) // 0: For You, 1: Following
    val homeSubTab = _homeSubTab.asStateFlow()

    fun setTab(tab: Int) {
        _selectedTab.value = tab
    }

    fun setHomeSubTab(subTab: Int) {
        _homeSubTab.value = subTab
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectVideoForComments(videoId: Long?) {
        _selectedVideoId.value = videoId
        if (videoId != null) {
            viewModelScope.launch {
                commentDao.getCommentsForVideo(videoId).collect { list ->
                    _comments.value = list
                }
            }
        } else {
            _comments.value = emptyList()
        }
    }

    fun toggleLike(video: VideoEntity) {
        viewModelScope.launch {
            val newIsLiked = !video.isLiked
            val newCount = if (newIsLiked) video.likesCount + 1 else maxOf(0, video.likesCount - 1)
            videoDao.updateLike(video.id, newIsLiked, newCount)
        }
    }

    fun toggleFollow(username: String, currentStatus: Boolean) {
        viewModelScope.launch {
            videoDao.updateFollow(username, !currentStatus)
        }
    }

    fun addComment(videoId: Long, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            val comment = CommentEntity(
                videoId = videoId,
                username = "my_korim_user",
                userAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200",
                text = text
            )
            commentDao.insertComment(comment)
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "New Comment",
                    message = "You commented on video #${videoId}",
                    type = "comment"
                )
            )
        }
    }

    fun uploadVideo(title: String, videoUri: String, caption: String, soundName: String) {
        viewModelScope.launch {
            val newVideo = VideoEntity(
                title = title.ifBlank { "Untitled Video" },
                videoUrl = videoUri,
                thumbnailUrl = "https://images.unsplash.com/photo-1518770660439-4636190af475?w=800",
                username = "my_korim_user",
                userAvatar = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=200",
                likesCount = 0,
                commentsCount = 0,
                isLiked = false,
                isFollowing = false,
                caption = caption.ifBlank { "Check out my new video! #korim" },
                soundName = soundName.ifBlank { "Original Sound - my_korim_user" }
            )
            videoDao.insertVideo(newVideo)
            notificationDao.insertNotification(
                NotificationEntity(
                    title = "Video Uploaded",
                    message = "Your video '${newVideo.title}' was posted successfully.",
                    type = "system"
                )
            )
            _selectedTab.value = 0 // Return to Home feed
        }
    }

    fun markNotificationsRead() {
        viewModelScope.launch {
            notificationDao.markAllAsRead()
        }
    }
}
