package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val KorimRed = Color(0xFFFF2D55)
val KorimRedDark = Color(0xFFC7002B)
val KorimBlack = Color(0xFF000000)
val KorimSurface = Color(0xFF121212)
val KorimSurfaceVariant = Color(0xFF1E1E1E)
val KorimWhite = Color(0xFFFFFFFF)
val KorimGray = Color(0xFF8E8E93)
val KorimDarkGray = Color(0xFF2C2C2E)
