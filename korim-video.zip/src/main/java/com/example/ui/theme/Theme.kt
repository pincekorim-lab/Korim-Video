package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val KorimDarkColorScheme = darkColorScheme(
    primary = KorimRed,
    onPrimary = KorimWhite,
    secondary = KorimRedDark,
    onSecondary = KorimWhite,
    background = KorimBlack,
    onBackground = KorimWhite,
    surface = KorimSurface,
    onSurface = KorimWhite,
    surfaceVariant = KorimSurfaceVariant,
    onSurfaceVariant = KorimWhite,
    outline = KorimGray
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Korim is primarily a dark-themed video app
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = KorimDarkColorScheme,
        typography = Typography,
        content = content
    )
}
