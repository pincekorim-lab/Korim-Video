package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@Database(entities = [VideoEntity::class, CommentEntity::class, NotificationEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao
    abstract fun commentDao(): CommentDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "korim_video_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch {
                    populateInitialData(database.videoDao(), database.commentDao(), database.notificationDao())
                }
            }
        }
    }
}

suspend fun populateInitialData(videoDao: VideoDao, commentDao: CommentDao, notificationDao: NotificationDao) {
    if (videoDao.getVideoCount() == 0) {
        val v1 = VideoEntity(
            title = "Amazing Sunset View",
            videoUrl = "https://assets.mixkit.co/videos/preview/mixkit-tree-branches-in-the-breeze-1186-large.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800",
            username = "elena_vibe",
            userAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200",
            likesCount = 1420,
            commentsCount = 2,
            isLiked = false,
            isFollowing = true,
            caption = "Nothing beats golden hour at the coast! #sunset",
            soundName = "Original Sound - Elena Vibe"
        )
        val v2 = VideoEntity(
            title = "Epic Skateboarding Trick",
            videoUrl = "https://assets.mixkit.co/videos/preview/mixkit-forest-stream-in-the-sunlight-529-large.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1520045892732-304bc3ac5d8e?w=800",
            username = "skater_boy",
            userAvatar = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=200",
            likesCount = 8920,
            commentsCount = 1,
            isLiked = true,
            isFollowing = false,
            caption = "New kickflip line down the plaza! #skate",
            soundName = "Adrenaline Rush - Beats"
        )
        val v3 = VideoEntity(
            title = "Quick Chef Pasta",
            videoUrl = "https://assets.mixkit.co/videos/preview/mixkit-waves-in-the-water-1164-large.mp4",
            thumbnailUrl = "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800",
            username = "chef_marco",
            userAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200",
            likesCount = 23400,
            commentsCount = 0,
            isLiked = false,
            isFollowing = true,
            caption = "Creamy truffle pasta in under 10 minutes! #food",
            soundName = "Cooking Chill Lofi"
        )

        val id1 = videoDao.insertVideo(v1)
        val id2 = videoDao.insertVideo(v2)
        videoDao.insertVideo(v3)

        commentDao.insertComment(CommentEntity(videoId = id1, username = "sarah_w", userAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200", text = "Breathtaking view!"))
        commentDao.insertComment(CommentEntity(videoId = id1, username = "mike_dev", userAvatar = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200", text = "Amazing!"))
        commentDao.insertComment(CommentEntity(videoId = id2, username = "skater_girl", userAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200", text = "Cleanest landing!!"))

        notificationDao.insertNotification(NotificationEntity(title = "New Like", message = "sarah_w liked your video.", type = "like"))
        notificationDao.insertNotification(NotificationEntity(title = "New Follower", message = "chef_marco started following you.", type = "follow"))
        notificationDao.insertNotification(NotificationEntity(title = "Welcome", message = "Welcome to Korim Video!", type = "system"))
    }
}
